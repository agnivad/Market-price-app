from django.apps import AppConfig


class MarketpriceConfig(AppConfig):
    name = 'MarketPrice'
