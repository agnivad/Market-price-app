from MarketPrice.models import StockPrice
from datetime import datetime


def parse_data(data):
    """

    :param data:
    :return:
    """
    temp = data['date'].split("T")[0]
    temp = datetime.strptime(temp, '%Y-%m-%d')
    data['date'] = datetime.strftime(temp, '%Y-%m-%d')
    return data


def save_data(data_list):
    """

    :param data_list:
    :return:
    """
    try:
        for item in data_list:
            data = parse_data(item)

            result = StockPrice.objects.filter(symbol=data['symbol'], date=data['date']).exists()

            if not result:
                StockPrice.objects.create(
                    open=data['open'],
                    high=data['high'],
                    low=data['low'],
                    close=data['close'],
                    volume=data['volume'],
                    adj_high=data['adj_high'],
                    adj_low=data['adj_low'],
                    adj_close=data['adj_close'],
                    adj_open=data['adj_open'],
                    adj_volume=data['split_factor'],
                    split_factor=data['split_factor'],
                    symbol=data['symbol'],
                    exchange=data['exchange'],
                    date=data['date'],
                )

    except Exception as e:
        raise e
