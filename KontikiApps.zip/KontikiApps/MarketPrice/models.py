from django.db import models


class StockPriceManager(models.Manager):
    """

    """
    def highest_increment(self):
        # todo: try except for latest_2
        latest = StockPrice.objects.values('date').latest('date')
        latest_2 = StockPrice.objects.all().order_by('-date').values('date').distinct()[4]


        return self.first()


class StockPrice(models.Model):
    #todo: make symbol and date unique together
    open = models.FloatField()
    high = models.FloatField()
    low = models.FloatField()
    close = models.FloatField()
    volume = models.FloatField()
    adj_high = models.FloatField()
    adj_low = models.FloatField()
    adj_close = models.FloatField()
    adj_open = models.FloatField()
    adj_volume = models.FloatField()
    split_factor = models.FloatField()
    symbol = models.CharField(max_length=10)
    exchange = models.CharField(max_length=10)
    date = models.DateField()
    objects = StockPriceManager()
