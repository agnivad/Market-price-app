from __future__ import absolute_import, unicode_literals

from celery import shared_task
import requests

from MarketPrice.config import COMPANY_LIST, MARKETSTACK_API_KEY, MARKETSTACK_LAST_EOD_URL
from MarketPrice.helpers import save_data


@shared_task
def get_data():
    try:
        company_list = ",".join(COMPANY_LIST)

        params = {
            "access_key": MARKETSTACK_API_KEY,
            "symbols": company_list
        }

        api_result = requests.get(MARKETSTACK_LAST_EOD_URL, params)
        api_response = api_result.json()
        data = api_response.get("data")

        # save data onto the database using save_data helper method
        save_data(data)

    except Exception:
        pass
