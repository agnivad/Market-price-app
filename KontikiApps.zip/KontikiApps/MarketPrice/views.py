from django.shortcuts import render
from django.http import HttpResponse
from MarketPrice.models import StockPrice
from MarketPrice.config import COMPANY_LIST

from django.views.generic import TemplateView
from chartjs.views.lines import BaseLineChartView


def index(request):
    return HttpResponse("Hello, world. You're at the MarketPrice index.")


class LineChartJSONView(BaseLineChartView):

    def __init__(self):
        self.result = StockPrice.objects.values_list('date', 'symbol', 'close').order_by('-date')[:30]

    def get_labels(self):
        """Return dates for the x-axis."""
        dates = [self.result[idx][0] for idx in range(0, len(self.result), 6)]
        return dates

    def get_providers(self):
        """Return names of companies."""
        return COMPANY_LIST

    def get_data(self):
        """Return 3 datasets to plot."""
        total_companies = len(COMPANY_LIST)

        price_list = list()
        for company in range(total_companies):
            price_list.append(list())

        for idx in range(len(self.result)):
            price_list[idx % total_companies].append(self.result[idx][2])

        return price_list


line_chart = TemplateView.as_view(template_name='price_history.html')
line_chart_json = LineChartJSONView.as_view()
